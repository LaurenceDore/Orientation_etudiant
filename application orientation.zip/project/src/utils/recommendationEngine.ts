import { Module, UserResponse } from '../types';
import { modules } from '../data/modules';

export function getModuleRecommendations(userResponses: UserResponse[]) {
  const recommendations = modules.map(module => {
    const matchScore = calculateMatchScore(module, userResponses);
    const reasons = generateReasons(module, userResponses);
    
    return {
      module,
      matchScore,
      reasons
    };
  });

  return recommendations
    .filter(rec => rec.matchScore > 0)
    .sort((a, b) => b.matchScore - a.matchScore);
}

function calculateMatchScore(module: Module, responses: UserResponse[]): number {
  let score = 0;
  
  // Implement scoring logic based on user responses and module objectives
  // This is a simplified example
  responses.forEach(response => {
    response.answer.forEach(answer => {
      if (module.objectives.some(obj => 
        obj.toLowerCase().includes(answer.toLowerCase())
      )) {
        score += 1;
      }
    });
  });

  return score;
}

function generateReasons(module: Module, responses: UserResponse[]): string[] {
  const reasons: string[] = [];
  
  // Generate explanation for why this module was recommended
  if (module.availability === 'Disponible') {
    reasons.push('Ce module est actuellement disponible');
  }
  
  // Add more sophisticated reason generation based on matches
  
  return reasons;
}