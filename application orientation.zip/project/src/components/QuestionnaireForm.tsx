import React, { useState } from 'react';
import { Question, UserResponse } from '../types';
import { questions } from '../data/questions';

interface Props {
  onSubmit: (responses: UserResponse[]) => void;
}

export default function QuestionnaireForm({ onSubmit }: Props) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [responses, setResponses] = useState<UserResponse[]>([]);

  const handleAnswer = (answer: string[]) => {
    const newResponses = [
      ...responses,
      { questionId: questions[currentQuestion].id, answer }
    ];
    
    setResponses(newResponses);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      onSubmit(newResponses);
    }
  };

  const question = questions[currentQuestion];

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="mb-8">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
          />
        </div>
        <p className="text-sm text-gray-600 mt-2">
          Question {currentQuestion + 1} sur {questions.length}
        </p>
      </div>

      <h2 className="text-xl font-semibold mb-6">{question.text}</h2>

      <div className="space-y-3">
        {question.options.map((option, index) => (
          <button
            key={index}
            onClick={() => handleAnswer([option])}
            className="w-full p-4 text-left border rounded-lg hover:bg-blue-50 
                     transition-colors duration-200"
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}