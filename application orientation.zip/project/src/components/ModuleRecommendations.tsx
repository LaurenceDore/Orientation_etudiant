import React from 'react';
import { ModuleRecommendation } from '../types';

interface Props {
  recommendations: ModuleRecommendation[];
}

export default function ModuleRecommendations({ recommendations }: Props) {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6">Modules Recommandés</h2>
      
      <div className="grid gap-6">
        {recommendations.map((rec, index) => (
          <div 
            key={rec.module.code}
            className="bg-white p-6 rounded-lg shadow-lg border-l-4 border-blue-500"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-semibold">{rec.module.name}</h3>
                <p className="text-gray-600">{rec.module.code}</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm ${
                rec.module.availability === 'Disponible' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {rec.module.availability}
              </span>
            </div>

            <h4 className="font-medium mb-2">Objectifs :</h4>
            <ul className="list-disc list-inside mb-4 space-y-1">
              {rec.module.objectives.map((obj, i) => (
                <li key={i} className="text-gray-700">{obj}</li>
              ))}
            </ul>

            {rec.reasons.length > 0 && (
              <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                <h4 className="font-medium mb-2">Pourquoi ce module ?</h4>
                <ul className="list-disc list-inside space-y-1">
                  {rec.reasons.map((reason, i) => (
                    <li key={i} className="text-gray-700">{reason}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}