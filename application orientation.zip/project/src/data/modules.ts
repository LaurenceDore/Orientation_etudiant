import { Module } from '../types';

export const modules: Module[] = [
  {
    code: 'DOEPS1005',
    name: 'Optimiser sa présence Social Media (SMO)',
    objectives: [
      'Comprendre l\'univers du SMO',
      'Connaître les principaux réseaux sociaux',
      'Acquérir des techniques d\'optimisation et de visibilité',
      'Élaborer une stratégie Social Media'
    ],
    availability: 'Disponible'
  },
  // Adding a few more examples - you would add all modules here
  {
    code: 'DOEPS1024',
    name: 'Concevoir un site avec HTML/CSS',
    objectives: [
      'Comprendre les enjeux de l\'univers du développement web',
      'Créer des sites internet',
      'Appliquer la théorie par la pratique'
    ],
    availability: 'Disponible'
  }
];