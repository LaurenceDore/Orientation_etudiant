import { Question } from '../types';

export const questions: Question[] = [
  {
    id: 'interest-1',
    text: 'Quels domaines de l\'informatique vous intéressent le plus ?',
    options: [
      'Développement web',
      'Marketing digital',
      'Base de données',
      'Réseaux et systèmes',
      'Design et UX'
    ],
    category: 'interest'
  },
  {
    id: 'experience-1',
    text: 'Quel est votre niveau actuel en programmation ?',
    options: [
      'Débutant complet',
      'Notions de base',
      'Niveau intermédiaire',
      'Niveau avancé'
    ],
    category: 'experience'
  },
  {
    id: 'goals-1',
    text: 'Quels sont vos objectifs professionnels ?',
    options: [
      'Devenir développeur web',
      'Travailler dans le marketing digital',
      'Spécialiste en base de données',
      'Administration système et réseau',
      'UX/UI Designer'
    ],
    category: 'goals'
  }
];