export interface Module {
  code: string;
  name: string;
  objectives: string[];
  availability: string;
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  category: 'interest' | 'experience' | 'goals';
}

export interface UserResponse {
  questionId: string;
  answer: string[];
}

export interface ModuleRecommendation {
  module: Module;
  matchScore: number;
  reasons: string[];
}